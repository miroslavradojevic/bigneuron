#ifndef X_H
#define X_H

class X
{
public:

    float x;
    float y;
    float z;

    float vx;
    float vy;
    float vz;

    float sig;
    float corr;
    float w;

    X();
    X(float _x, float _y, float _z, float _vx, float _vy, float _vz, float _w);
//    X(X& xin);

};

#endif // X_H
