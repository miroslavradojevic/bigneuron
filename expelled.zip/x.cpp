#include "x.h"

X::X(){

    x = 0;
    y = 0;
    z = 0;

    vx = 0;
    vy = 0;
    vz = 0;

    sig     = 0;
    w       = 0;
    corr    = 0;

}

X::X(float _x, float _y, float _z, float _vx, float _vy, float _vz, float _w){

    x = _x;
    y = _y;
    z = _z;

    vx = _vx;
    vy = _vy;
    vz = _vz;

    sig = 0;
    w = _w;
    corr = 0;

}

//X::X(X& xin){

//    x = xin.x;
//    y = xin.y;
//    z = xin.z;

//    vx = xin.vx;
//    vy = xin.vy;
//    vz = xin.vz;

//    sig = 0;
//    w = xin.w;
//    corr = xin.corr;
//}


